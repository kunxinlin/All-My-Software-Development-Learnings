package academy.learnprogramming;

public interface MessageGenerator {

    String getMainMessage();

    String getResultMessage();
}
